#!/bin/bash

#chmod +x eth_switch1.sh
#chmod +x eth_switch2.sh
#chmod +x eth_switch3.sh
#chmod +x eth_switch4.sh

#chmod +x eth_host1.sh
#chmod +x eth_host2.sh

chmod +x eth.sh
chmod +x clean_all.sh
chmod +x reno.sh
#chmod +x eth_all.sh

chmod +x h1.sh
#chmod +x h2.sh
#chmod +x h3.sh
chmod +x h4.sh
#chmod +x h5.sh
#chmod +x h6.sh
#chmod +x h7.sh
#chmod +x h8.sh
#chmod +x h9.sh
#chmod +x h10.sh


chmod +x forwarding_table_normal.sh
